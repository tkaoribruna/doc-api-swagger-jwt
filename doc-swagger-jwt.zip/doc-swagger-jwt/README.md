//Discente: Bruna Kaori Takuti
//RA: a2706342

# API-Tasks e Receitas
Documentação de API com Swagger e Autenticação JWT

1. Instale dependências:
npm install

2. Inicie a aplicação:
node app.js

A aplicação rodará em "http://localhost:3000".

## Usuário e Senha
- Usuário: `admin`
- Senha: `1234`

## Swagger UI
Servidor em: "http://localhost:3000/api-docs":

## Prints com testes no Postman na pasta "testes-postman"
## Prints com testes no Swagger na pasta "testes-swagger"

## Arquivos 
- `app.js` — inicialização do servidor
- `routes.js` — definições das rotas
- `controllers/` — controladores das entidades (Criado de acordo com o arquivo roters.js na apostila)
- `middleware/authenticateToken.js` — middleware JWT
- `swagger.json` — especificação OpenAPI
